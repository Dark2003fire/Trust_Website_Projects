<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--[if lt IE 9]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <title>Page not found | Charity</title>
<meta name='robots' content='noindex,follow' />
<link rel="alternate" type="application/rss+xml" title="Charity &raquo; Feed" href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/feed/" />
<link rel="alternate" type="application/rss+xml" title="Charity &raquo; Comments Feed" href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/comments/feed/" />
<link rel='stylesheet' id='contact-form-7-css'  href='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='wppd-style-css'  href='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/easypay/public/css/wppd-public.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='events-manager-css'  href='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/events-manager/includes/css/events_manager.css?ver=5.55' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/revslider/rs-plugin/css/settings.css?ver=4.6.5' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-layout-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=2.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=2.3.7' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=2.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='mailchimp-for-wp-checkbox-css'  href='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/mailchimp-for-wp/assets/css/checkbox.min.css?ver=2.2.8' type='text/css' media='all' />
<link rel='stylesheet' id='chy.fonts-css' href="https://fonts.googleapis.com/css?family=Lato:400,300italic,300,700%7CPlayfair+Display:400,700italic%7CRoboto:300%7CMontserrat:400,700%7COpen+Sans:400,300%7CLibre+Baskerville:400,400italic" type='text/css' media='all' />
<link rel='stylesheet' id='chy-lora-fonts-css' href="https://fonts.googleapis.com/css?family=Lora:400italic" type='text/css' media='all' />
<link rel='stylesheet' id='chy.style-css'  href='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='chy.bootstrap-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/css/bootstrap.css' type='text/css' media='all' />
<link rel='stylesheet' id='chy.bootstrap.theme-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/css/bootstrap-theme.css' type='text/css' media='all' />
<link rel='stylesheet' id='chy-fancybox-css-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/fancybox/css/fancybox.css' type='text/css' media='all' />
<link rel='stylesheet' id='chy.font-awesome-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/css/font-awesome.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='chy.switcher.theme.panel-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/switcher/assets/css/theme_panel.css' type='text/css' media='all' />
<link rel='stylesheet' id='chy.global-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/css/global.css' type='text/css' media='all' />
<link rel='stylesheet' id='chy.custom.style-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/css/chy-style.css' type='text/css' media='all' />
<link rel='stylesheet' id='chy.responsive-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/css/responsive.css' type='text/css' media='all' />
<link rel='stylesheet' id='chy.skin-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/css/skin.css' type='text/css' media='all' />
<link rel='stylesheet' id='charity.owl.carousel-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/css/owl.carousel.css' type='text/css' media='all' />
<link rel='stylesheet' id='charity.owl.theme-css'  href='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/css/owl.theme.css' type='text/css' media='all' />
<link rel='stylesheet' id='mailchimp-for-wp-form-css'  href='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/mailchimp-for-wp/assets/css/form.min.css?ver=2.2.8' type='text/css' media='all' />
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/jquery.js?ver=1.11.1'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/easypay/public/js/libs/jquery-validation/jquery.validate.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/easypay/public/js/libs/jquery-validation/additional-methods.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='https://js.stripe.com/v2/?ver=1.0.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wppd_display = {"loader_url":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/wp-content\/plugins\/easypay\/public\/images\/icons\/ajax-loader.gif","ajaxurl":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/wp-admin\/admin-ajax.php","template_url":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/wp-content\/themes\/charity","paypal_fee":"2.9","stripe_pk_key":"pk_test_y4Ot3N4ZDWL6jb2xH8nHABEp","strip_success_url":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/thank-you\/"};
/* ]]> */
</script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/easypay/public/js/wppd-public.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/core.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/position.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/mouse.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/sortable.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/menu.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/autocomplete.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/resizable.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/draggable.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/button.min.js?ver=1.11.2'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/js/jquery/ui/dialog.min.js?ver=1.11.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var EM = {"ajaxurl":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/wp-admin\/admin-ajax.php","locationajaxurl":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/wp-admin\/admin-ajax.php?action=locations_search","firstDay":"1","locale":"en","dateFormat":"dd\/mm\/yy","ui_css":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/wp-content\/plugins\/events-manager\/includes\/css\/ui-lightness.css","show24hours":"","is_ssl":"","bookingInProgress":"Please wait while the booking is being submitted.","tickets_save":"Save Ticket","bookingajaxurl":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/wp-admin\/admin-ajax.php","bookings_export_save":"Export Bookings","bookings_settings_save":"Save Settings","booking_delete":"Are you sure you want to delete?","bb_full":"Sold Out","bb_book":"Book Now","bb_booking":"Booking...","bb_booked":"Booking Submitted","bb_error":"Booking Error. Try again?","bb_cancel":"Cancel","bb_canceling":"Canceling...","bb_cancelled":"Cancelled","bb_cancel_error":"Cancellation Error. Try again?","txt_search":"Search","txt_searching":"Searching...","txt_loading":"Loading..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/events-manager/includes/js/events-manager.js?ver=5.55'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.tools.min.js?ver=4.6.5'></script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.revolution.min.js?ver=4.6.5'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.1.31" />
<meta name="generator" content="WooCommerce 2.3.7" />
		<script type="text/javascript">
			jQuery(document).ready(function() {
				// CUSTOM AJAX CONTENT LOADING FUNCTION
				var ajaxRevslider = function(obj) {
				
					// obj.type : Post Type
					// obj.id : ID of Content to Load
					// obj.aspectratio : The Aspect Ratio of the Container / Media
					// obj.selector : The Container Selector where the Content of Ajax will be injected. It is done via the Essential Grid on Return of Content
					
					var content = "";

					data = {};
					
					data.action = 'revslider_ajax_call_front';
					data.client_action = 'get_slider_html';
					data.token = '5bf4f07a5c';
					data.type = obj.type;
					data.id = obj.id;
					data.aspectratio = obj.aspectratio;
					
					// SYNC AJAX REQUEST
					jQuery.ajax({
						type:"post",
						url:"http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-admin/admin-ajax.php",
						dataType: 'json',
						data:data,
						async:false,
						success: function(ret, textStatus, XMLHttpRequest) {
							if(ret.success == true)
								content = ret.data;								
						},
						error: function(e) {
							console.log(e);
						}
					});
					
					 // FIRST RETURN THE CONTENT WHEN IT IS LOADED !!
					 return content;						 
				};
				
				// CUSTOM AJAX FUNCTION TO REMOVE THE SLIDER
				var ajaxRemoveRevslider = function(obj) {
					return jQuery(obj.selector+" .rev_slider").revkill();
				};

				// EXTEND THE AJAX CONTENT LOADING TYPES WITH TYPE AND FUNCTION
				var extendessential = setInterval(function() {
					if (jQuery.fn.tpessential != undefined) {
						clearInterval(extendessential);
						if(typeof(jQuery.fn.tpessential.defaults) !== 'undefined') {
							jQuery.fn.tpessential.defaults.ajaxTypes.push({type:"revslider",func:ajaxRevslider,killfunc:ajaxRemoveRevslider,openAnimationSpeed:0.3});   
							// type:  Name of the Post to load via Ajax into the Essential Grid Ajax Container
							// func: the Function Name which is Called once the Item with the Post Type has been clicked
							// killfunc: function to kill in case the Ajax Window going to be removed (before Remove function !
							// openAnimationSpeed: how quick the Ajax Content window should be animated (default is 0.3)
						}
					}
				},30);
			});
		</script>
		<link rel="shortcut icon" type="image/x-icon" href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/favicon.ico"  /><style type="text/css">.mc4wp-form input[name="_mc4wp_required_but_not_really"] { display: none !important; }</style>    </head>
    <body class="error404">
        <div id="wrapper" class="full-width">
            <!--Header Section Start Here -->
            <header id="header">
    <div class="container">
        <div class="row primary-header">
                        <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/" class="col-xs-12 col-sm-2 brand" title="Charity"><img src="http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/img/logo.png" alt="Charity"></a>
            <div class="social-links col-xs-12 col-sm-10">
            	                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/become-volunteer/" class="btn btn-default btn-volunteer">Become volunteer</a>
                                  <ul class="social-icons hidden-xs">
                    <li class="social-facebook"><a href="https://facebook.com" target="blank"><i class="fa fa-facebook"></i></a></li>
                            <li class="social-google-plus"><a href="https://plus.google.com" target="blank"><i class="fa fa-google-plus"></i></a></li>
                            <li class="social-twitter"><a href="https://twitter.com" target="blank"><i class="fa fa-twitter"></i></a></li>
                            <li class="social-linkedin"><a href="http://linkedin.com" target="blank"><i class="fa fa-linkedin"></i></a></li>
                            <li class="social-vimeo-square"><a href="https://vimeo.com" target="blank"><i class="fa fa-vimeo-square"></i></a></li>
                    </ul>
                </div>
        </div>
    </div>
    <div class="navbar navbar-default" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <nav class="menu-single-causes-container"><ul id="menu-single-causes" class="nav navbar-nav"><li id="menu-item-540" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-540 submenu-icon"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/" data-toggle="dropdown">Home<span class="glyphicon glyphicon-chevron-down"></span> <span class="glyphicon glyphicon-chevron-up"></span></a>
<div class="dropdown-menu"><ul class="sub-menu menu-odd  menu-depth-1">
	<li id="menu-item-541" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-541"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/" >Home 4</a></li>
	<li id="menu-item-542" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-542"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/home-5/" >Home 5</a></li>
</ul></div>
</li>
<li id="menu-item-543" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-543 submenu-icon"><a href="#" data-toggle="dropdown">Features<span class="glyphicon glyphicon-chevron-down"></span> <span class="glyphicon glyphicon-chevron-up"></span></a>
<div class="dropdown-menu"><ul class="sub-menu menu-odd  menu-depth-1">
	<li id="menu-item-548" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-548"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/portfolio/" >Portfolio</a></li>
	<li id="menu-item-587" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-587"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/project-listing/" >Project Listing</a></li>
	<li id="menu-item-547" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-547"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/our-story/" >Our Story</a></li>
	<li id="menu-item-546" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-546"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/our-mission/" >Our Mission</a></li>
	<li id="menu-item-544" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-544"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/become-volunteer/" >Become Volunteer</a></li>
	<li id="menu-item-556" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-556"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/events/" >Events</a></li>
	<li id="menu-item-545" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-545"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/140-2/" >FAQ</a></li>
</ul></div>
</li>
<li id="menu-item-549" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-549 submenu-icon"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/shop/" data-toggle="dropdown">Shop<span class="glyphicon glyphicon-chevron-down"></span> <span class="glyphicon glyphicon-chevron-up"></span></a>
<div class="dropdown-menu"><ul class="sub-menu menu-odd  menu-depth-1">
	<li id="menu-item-551" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-551"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/shop/" >Shop</a></li>
	<li id="menu-item-550" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-550"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/my-account/" >My Account</a></li>
</ul></div>
</li>
<li id="menu-item-554" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-554"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/gallery/" >Gallery</a></li>
<li id="menu-item-552" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-552"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/blog/" >Blog</a></li>
<li id="menu-item-553" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-553"><a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/contact-us/" >Contact Us</a></li>
</ul></nav> 

                <form class="navbar-form navbar-right search-form" role="search" method="get" action="http://theemon.com/c/charity-wp/LivePreview/SingleCause/">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Search Here" name="s">
                    </div>
                    <button type="submit">
                        <i class="icon-search"></i>
                    </button>
                </form>

            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </div>

</header>
            <!-- Header Section End Here -->
            <!-- Site Content -->
            <div id="main">		
<section class="container" id="page-info">
    <div class="row">
        <!-- Table Section Start Here -->
        <div class="col-xs-12 col-md-8 col-md-offset-2 four-zero-four">
            <strong>404</strong>

            <header class="page-header">
                <h2>No Page Found. Something is Wrong</h2>
                <p>
                    Phllus felis purus placerat vel augue vitae aliquam tincidunt dolor sed hendrerit diam in mat tis mollis donecut Phasellus felis purus placerat vel augue vitae, Sed hendrerit diam in mattis mollis.                </p>
            </header>
            <a class="btn btn-default" href="http://theemon.com/c/charity-wp/LivePreview/SingleCause">BACK TO HOMEPAGE</a>

        </div>		

    </div>

</section>

</div>
<!--Footer Section Start Here -->
<footer id="footer" class="footer-one">
    
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-4">
            	                		 <div class="footer-logo">
								<a href="" title="Welcome to Charity">Charity</a>
							</div>
							<p>
								There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, 							</p>
							<address>
								<span> <i class="fa fa-home"></i> <span>A-2, Sector-63, Noida, 201301, India</span> </span>
								<span> <i class="fa fa-phone-square"></i> <span>+1 707 921 7269</span> </span>
								<span> <i class="fa fa-envelope"></i> <span><a href="/cdn-cgi/l/email-protection#e5868a8b91848691a5868d84978c919ccb868a88"><span class="__cf_email__" data-cfemail="3a5955544e5b594e7a59525b48534e4314595557">[email&#160;protected]</span></a></span> </span>
							</address>

		
	                               </div>
            <div class="col-xs-12 col-sm-4 twitter-update">
            	                <h6>Twitter Widget</h6>                    <p>
                    	<a href="https://twitter.com/sparx96897784" target="_blank"> 
                    		<span class="charity">@sparx96897784 </span> 
                    	</a>
                    	Design Specialists + Strategic Process + Core Message 
+ Supplemental Marketing Material = Brand Identity <a target="_blank" href="https://t.co/rb05v3pu2m">https://t.co/rb05v3pu2m</a> 
                    	<span class="comment-time"> 3 year ago.</span> 
                    	
					</p>
                    
                                     <p>
                    	<a href="https://twitter.com/sparx96897784" target="_blank"> 
                    		<span class="charity">@sparx96897784 </span> 
                    	</a>
                    	Exsistit autem hoc loco quaedam quaestio subdifficilis, num quando amici novi, digni amicitia, veteribus sint antep… <a target="_blank" href="https://t.co/umkOEsXTN6">https://t.co/umkOEsXTN6</a> 
                    	<span class="comment-time"> 3 year ago.</span> 
                    	
					</p>
                    
                                     <p>
                    	<a href="https://twitter.com/sparx96897784" target="_blank"> 
                    		<span class="charity">@sparx96897784 </span> 
                    	</a>
                    	<a target="_blank" href="http://103.82.221.21/full-cycle/product/a-trip-to-the-rainforest/">http://103.82.221.21/full-cycle/product/a-trip-to-the-rainforest/</a>   test number 10 
                    	<span class="comment-time"> 4 year ago.</span> 
                    	
					</p>
                    
                  
                            </div>
            <div class="col-xs-12 col-sm-4 newsletter-social-icon">
            	            	<h6>Newsletter Signup</h6>			<div class="textwidget"><p>Variations of passages of Lorem Ipsum available, but the majokgrity</p> <!-- Form by MailChimp for WordPress plugin v2.2.8 - https://mc4wp.com/ --><div id="mc4wp-form-1" class="form mc4wp-form"><form method="post"><p>
	<label>Email address: </label>
	<input type="email" id="mc4wp_email" name="EMAIL" placeholder="Email" required />
</p>

<p>
	<input type="submit" value="SUBMIT" />
</p><input type="text" name="_mc4wp_required_but_not_really" value="" /><input type="hidden" name="_mc4wp_timestamp" value="1663271034" /><input type="hidden" name="_mc4wp_form_submit" value="1" /><input type="hidden" name="_mc4wp_form_instance" value="1" /><input type="hidden" name="_mc4wp_form_nonce" value="cead88b1ab" /></form></div><!-- / MailChimp for WP Plugin --></div>
				<div class="social-media-widget">
			<h6>Follow us</h6>
			<ul class="social-icons">
				         								<li>
									<a target="_blank" href="https://facebook.com"><i class="fa fa-facebook"></i></a>
								</li>
					
						
											<li>
									<a target="_blank" href="https://twitter.com"><i class="fa fa-twitter"></i></a>
								</li>
																								<li>
									<a target="_blank" href="http://dribble.com"><i class="fa fa-dribbble"></i></a>
								</li>
																								<li>
									<a target="_blank" href="https://pinterest.com"><i class="fa fa-pinterest"></i></a>
								</li>
																								<li>
									<a target="_blank" href="https://plus.google.com"><i class="fa fa-google-plus"></i></a>
								</li>
																								<li>
									<a target="_blank" href="https://instagram.com"><i class="fa fa-instagram"></i></a>
								</li>
															</ul>				
</div>
		
	            	                <!-- <h6>Follow us</h6> 
                <ul class="social-icons">
                     
                </ul>-->
            </div>
        </div>
    </div>
    
    <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <span>© Copyright 2016, All Rights Reserved by Charity Theme.</span>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--Footer Section End Here -->
<div class="site-mode">
    <a href="http://theemon.com/c/charity-wp/LivePreview/MultipleCauses/">View Multiple Causes Demo</a>
</div>
</div>

<div id="theme_panel">
    <a href="https://themeforest.net/item/charity-nonprofitngofundraising-wordpress-theme/11276287?license=regular&open_purchase_for_item_id=11276287&purchasable=source&ref=theemon" class="theme-setting shop-now" target="_blank"><span></span></a>
<span class="theme-setting"> <i></i> </span>
<div id="styleSwitcher">

    <div class="panel-heading yellow-brder">
        <h2 class="heading center">Settings &amp; Options</h2>
    </div>
    <div id="layout" class="theme_panel_inner btm-brder">
        <div class="theme-heading">
            <h3 class="heading">LAYOUT</h3>
            <i class="fa fa-plus"></i>
        </div>
        <div class="theme_panel_option">
            <div class="layout-style">
                <a href="javascript:;">
                    <div id="full-width" class="layout-column radio-active" data-layout="fullWidth">
                        <span class="column-text">Full-width</span>
                        <i id="width-style" class="radio"></i>

                    </div> </a>
                <a href="javascript:void(0)">
                    <div id="boxed" class="layout-column" data-layout="boxed">
                        <span class="column-text">boxed</span>
                        <i id="box-style" class="radio"></i>

                    </div></a>
            </div>
            <div class="note">
                <strong><i class="fa fa-check note-point"></i> Note:</strong>
                <p>
                    Website is responsive so you all set for
                    any customization.
                </p>
            </div>
        </div>
    </div>

    <div id="color" class="theme_panel_inner btm-brder">
        <div class="theme-heading ">
            <h3 class="heading">COLORS</h3>
            <i class="fa fa-plus"></i>
        </div>
        <div class="theme_panel_option">
            <ul class="swatches">

            </ul>

            <div class="note">
                <strong><i class="fa fa-check note-point"></i> Note:</strong>
                <p>
                    Website is responsive so you all set for
                    any customization.
                </p>
            </div>
        </div>

    </div>

    <div id="fonts" class="theme_panel_inner btm-brder">
        <div class="theme-heading ">
            <h3 class="heading">FONTS</h3>
            <i class="fa fa-plus"></i>
        </div>
        <div class="theme_panel_option">
            <select class="select-font">

            </select>
        </div>

    </div>

    <div id="sticky" class="theme_panel_inner btm-brder">
        <div class="theme-heading">
            <h3 class="heading">STICKY HEADER</h3>
            <i class="fa fa-plus"></i>
        </div>
        <div class="theme_panel_option">
            <div class="layout-style">
                <a href="javascript:void(0)">
                    <div id="sticky-no" class="layout-column radio-active" rel="no">
                        <span class="column-text">Normal</span>
                        <i id="width-style" class="radio"></i>

                    </div> </a>
                <a href="javascript:void(0)">
                    <div id="sticky-yes" class="layout-column" rel="yes">
                        <span class="column-text">intelligent</span>
                        <i id="box-style" class="radio"></i>

                    </div></a>
            </div>
            <div class="note">
                <strong><i class="fa fa-check note-point"></i> Note:</strong>
                <p>
                    Website is responsive so you all set for
                    any customization.
                </p>
            </div>
        </div>
    </div>
    <div id="short-codes" class="theme_panel_inner btm-brder">
        <div class="theme-heading">
            <h3 class="heading">Short Codes</h3>
            <i class="fa fa-plus"></i>
        </div>
        <div class="theme_panel_option fix-scroll">
            <div class="page-group">
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/html/typography/" class="active-page">Typography</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/html/tabs/">Tabs</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/html/accordian/">Accordion/Toggle Box</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/html/notification/">Notification Boxes</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/html/slider-ranger/">Slider Ranger</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/html/tables/">TABLES</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/html/list-style/">List Style</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/html/blockquote/">Blockquote</a>
            </div>
        </div>
    </div>


    <div id="allpages" class="theme_panel_inner btm-brder">
        <div class="theme-heading">
            <h3 class="heading">All pages</h3>
            <i class="fa fa-plus"></i>
        </div>
        <div class="theme_panel_option fix-scroll">
            <div class="page-group">
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/home-1/" class="active-page">Index Page</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/home-2/">Index-2</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/home-3/">Index-3</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/our-story/">Our Story</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/our-mission/">Our Mission</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/become-volunteer/">Become a Volunteer</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/gallery/">Gallery 2 Columns</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/html/gallery-three-columns/">Gallery 3 Columns</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/140-2/">Faq </a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/!404/">404 Error </a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/causes/">Causes Home</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/html/causes-details-full-width/">Causes Details full width</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/causes/help-african-children-to-get-shelter-3/">Causes Details with sidebar</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/portfolio/">Portfolio</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/charity-portfolio/heading-title-9/">Portfolio Detail</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/blog/">Blog Full Width</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/hendrerit-pellentesque-pellentesque-sed-ultrices-arcu-3/">Blog Detail Full Width</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/contact-us/">Contact us</a>
                <a href="http://theemon.com/c/charity-wp/LivePreview/SingleCause/coming-soon/">Coming Soon</a>
            </div>
        </div>
    </div>

</div>
</div>

        <div class="modal donate-form">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body charity-donation-window">
                        <!-- EASY PAY PLUGIN FORM -->
                    </div>
                </div>
            </div>
        </div>

        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript">
			(function() {

				function addSubmittedClass() {
					var className = 'mc4wp-form-submitted';
					(this.classList) ? this.classList.add(className) : this.className += ' ' + className;
				}

				var forms = document.querySelectorAll('.mc4wp-form');
				for (var i = 0; i < forms.length; i++) {
					(function(f) {

						// hide honeypot
						var honeypot = f.querySelector('input[name="_mc4wp_required_but_not_really"]');
						honeypot.style.display = 'none';
						honeypot.setAttribute('type','hidden');

						// add class on submit
						var b = f.querySelector('[type="submit"]');
						if(b.addEventListener) {
							b.addEventListener( 'click', addSubmittedClass.bind(f));
						} else {
							b.attachEvent( 'onclick', addSubmittedClass.bind(f));
						}

					})(forms[i]);
				}
			})();

					</script><script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.0.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/c\/charity-wp\/LivePreview\/SingleCause\/wp-admin\/admin-ajax.php","i18n_view_cart":"View Cart","cart_url":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=2.3.7'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.60'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/c\/charity-wp\/LivePreview\/SingleCause\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=2.3.7'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/c\/charity-wp\/LivePreview\/SingleCause\/wp-admin\/admin-ajax.php","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=2.3.7'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/js/bootstrap.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var charity = {"ajaxURL":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/wp-admin\/admin-ajax.php","template_url":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause\/wp-content\/themes\/charity","color":"#ecc731","layout":"full-width","sticky_header":"sticky-yes","global_font":"'Montserrat',sans-serif","home_url":"http:\/\/theemon.com\/c\/charity-wp\/LivePreview\/SingleCause"};
/* ]]> */
</script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/switcher/assets/js/switcher.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/switcher/assets/js/jquery.cookie.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/countdown/jquery.plugin.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/countdown/jquery.countdown.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/js/jquery.easing.min.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/js/jquery.flexslider.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/fancybox/js/jquery.fancybox.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/fancybox/js/custom.fancybox.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/js/custom-woocommerce.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/js/owl.carousel.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var charityCustom = {"countdown":"April 16, 2015 12:00:00"};
/* ]]> */
</script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/js/wp.custom.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/js/site.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/js/snap.svg-min.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/js/gauge.js'></script>
<script type='text/javascript' src='//theemon.com/c/charity-wp/LivePreview/SingleCause/wp-content/themes/charity/assets/js/gauge-custom.js'></script>
	
</body>
</html>
